// For posting a forms
function checkform(){
let x = document.forms["demoforms"] ["myname"].value;

// getting a value with alert box
// alert(x);
// getting a value with id
document.getElementById("demos").innerHTML=x.replace()  ;//string function for getting a values
document.getElementById("count").innerHTML=x.length; //string function for getting a length values
document.getElementById("slice").innerHTML=x.slice(1,5); //string function for getting extracting string a values
document.getElementById("substring").innerHTML=x.substring(1,5); //string function for getting a values
document.getElementById("capital").innerHTML=x.toUpperCase(); //string function for getting a values in uppercase
document.getElementById("lowercase").innerHTML=x.toLowerCase(); //string function for getting a values in lowercase
document.getElementById("trim").innerHTML=x.trim(); //string function for getting a values without any space
document.getElementById("padstart").innerHTML=x.padStart(2,0); //string function for start padding
document.getElementById("padend").innerHTML=x.padEnd(2,0); //string function for ending a padding
document.getElementById("charat").innerHTML=x.charAt(1); //string function for return specific position of string
document.getElementById("charcodeat").innerHTML=x.charCodeAt(2); //string function for returns the unicode of the character at a specified index in a string
document.getElementById("property").innerHTML=x[0]; //string function for property access on a string
return false; 

}


// Show and hide element with click

function show()
{
  var a = document.getElementById("sentence");
  if (a.style.display === "none") {
    a.style.display = "block";
    button.style.visiblity= "hidden";
  }
  else{
    a.style.display = "block";
    button.style.visiblity= "hidden";

  }
}
function hide()
{
  var a = document.getElementById("sentence");
  if (a.style.display === "block") {
    a.style.display = "none";
  }
  else{
    a.style.display = "none";
  }
}

//convert farenhit to salsiuc
function convert(degree){
    var x;
  if (degree == "C") {
    x = document.getElementById("c").value * 9 / 5 + 32;
    document.getElementById("f").value = x;
  } else {
    x = (document.getElementById("f").value -32) * 5 / 9;
    document.getElementById("c").value = (x);
  }
}
