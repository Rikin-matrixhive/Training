function checkvalidation() {
    event.preventDefault();
    var email = document.getElementById("myemail").value
    var pass = document.getElementById("mypass").value;
    var emailPattern = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$/;
    var passpattern = /^[a-z0-9]+$/i;
    let xhttp = new XMLHttpRequest();
    
    if (!emailPattern.test(myemail.value)) {
        alert('Please provide a valid email address');
        return false;
    }
    else {
        document.getElementById("demo").innerHTML = email;
    }
    if (!passpattern.test(mypass.value)) {
        alert('Please provide a valid password');
        return false;
    }
    else {
        document.getElementById("demo1").innerHTML = pass;

    }
    xhttp.getResponseHeader("content-type", "application/json")
    xhttp.open("get", "http://127.0.0.1:5500/usercredentials.json", true);
    xhttp.onload = function () {
        document.getElementById("name").innerHTML = this.responseText.email;

    xhttp.send();

}
}